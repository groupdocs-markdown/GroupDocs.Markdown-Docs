---
title: "Meridian Outdoor Co. — Annual Report 2025"
author: "Elena Márquez, CFO"
format: Docx
pages: 6
---

![](images/img-001.png)

**Annual Report 2025**

Meridian Outdoor Co.


## ******Table of Contents**

Annual Report 2025	1

Meridian Outdoor Co.	1

Table of Contents	2

Letter from the CEO	3

Financial Highlights	3

Revenue	3

By Segment	3

Apparel	3

Footwear	3

Camping	3

Accessories	3

Year-over-Year Trend	3

Operating Expenses	4

Operations Review	4

Supply Chain	4

Sourcing	4

Manufacturing	4

Warehousing	4

Sustainability Report	5

Materials	5

Energy	5

Segment Mix	5

Governance	5

Financial Statements	5

Income Statement	5

Balance Sheet	6

Cash Flow	6


## ******Letter from the CEO**

Fiscal year 2025 was a year of disciplined growth and measurable impact. We grew revenue to $8.7M, opened our flagship store in Portland, and began the sustainability audit that will culminate in certification during FY2026. Alongside these wins, we made the hard calls needed to position the business for the next stage: consolidating suppliers, rewriting our warranty program, and investing in a field-repair capability that most of our peers do not yet offer.

The pages that follow lay out what we built, what we learned, and where we are headed. Thank you for being part of the journey.

— Elena Márquez, Chief Executive Officer


## **Financial Highlights**


### ***Revenue***

Total FY2025 revenue reached $8.7M, representing forty-five percent year-over-year growth. All four product segments contributed to growth, with apparel and footwear leading the mix.


#### **By Segment**


##### **Apparel**

The apparel segment contributed $3.5M in FY2025 revenue, up forty-two percent year-over-year, driven by the Canyon Pant relaunch and the introduction of the Ridge Merino base layer.


##### **Footwear**

The Trailhead Boot became our top-selling SKU in Q3, contributing $2.2M for the segment. Initial customer research suggests the repair program is driving repeat purchase.


##### **Camping**

Camping gear posted $1.7M in revenue with expanding tent and cook-kit lines. The Coalfire Kit exceeded its launch plan by eighteen percent.


##### **Accessories**

Accessories closed the year at $1.3M, driven by repair-kit bundles and the new line of trail-maintenance tools for professional guides.


#### **Year-over-Year Trend**

The following chart shows quarterly revenue across the past three fiscal years. Q4 seasonality remains consistent with prior years, though Q2 growth reflects the earlier-than-usual launch of the spring apparel line.

![](images/img-002.png)


### ***Operating Expenses***

Operating expenses grew modestly relative to revenue, reflecting disciplined hiring and a renegotiated logistics contract.


| Category | FY2024 | FY2025 | Change |
| --- | --- | --- | --- |
| Cost of goods sold | $2.9M | $3.9M | +34% |
| Marketing | $0.7M | $1.0M | +43% |
| Operations | $1.1M | $1.5M | +36% |
| G&A | $0.5M | $0.7M | +40% |
| R&D | $0.3M | $0.5M | +67% |



## **Operations Review**


### ***Supply Chain***


#### **Sourcing**

We consolidated from eighteen to eleven primary suppliers during FY2025, with a focus on partners who can demonstrate transparent labour practices and traceable raw materials.


#### **Manufacturing**

Two new cut-and-sew partnerships were added in Portugal and Vietnam, both under multi-year agreements that include shared investment in automation.


### ***Warehousing***

The Portland warehouse expanded from 12,000 to 18,000 square feet, eliminating the need for third-party overflow storage during peak season.


## **Sustainability Report**


### ***Materials***

Seventy-two percent of catalog items now use recycled or certified organic materials for their primary fabrics, up from fifty-one percent in FY2024.


### ***Energy***

Scope 1 and Scope 2 emissions decreased by twelve percent year-over-year, largely from the switch to renewable electricity at the Portland facility.


### ***Segment Mix***

![](images/img-003.png)


## **Governance**

Our governance framework is built on three commitments: transparent reporting, independent oversight, and a direct feedback channel for employees and suppliers.

- Board composition — five members, three independent.
- Audit committee meets quarterly and reports directly to the board.
- Ethics policy updated in FY2025 to include supplier code of conduct.
- Whistleblower channel operated by an external third party.

## **Financial Statements**


### ***Income Statement***


| Line item | FY2024 | FY2025 |
| --- | --- | --- |
| Revenue | $6.0M | $8.7M |
| Cost of goods | $2.9M | $3.9M |
| Gross profit | $3.1M | $4.8M |
| Operating exp. | $2.6M | $3.7M |
| Operating income | $0.5M | $1.1M |
| Net income | $0.4M | $0.9M |



### ***Balance Sheet***


| Line item | FY2024 | FY2025 |
| --- | --- | --- |
| Cash | $1.1M | $2.0M |
| Inventory | $1.4M | $2.1M |
| Total assets | $4.8M | $7.0M |
| Total liabilities | $1.9M | $2.5M |
| Equity | $2.9M | $4.5M |



### ***Cash Flow***


| Line item | FY2024 | FY2025 |
| --- | --- | --- |
| From operations | $0.6M | $1.3M |
| From investing | ($0.3M) | ($0.8M) |
| From financing | ($0.1M) | ($0.2M) |
| Net change | $0.2M | $0.3M |
